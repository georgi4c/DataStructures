﻿namespace BunnyWars.Core
{
    public class BunnyWarsTestingGround
    {
        public static void Main()
        {
        }
    }
}